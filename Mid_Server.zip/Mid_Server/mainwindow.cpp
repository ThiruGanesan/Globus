#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    int icnt = 0;

    /* Widget Creation */
    QWidget *widget = new QWidget();

    /* PushButton  and Text Editor Creation */
    PB_Start = new QPushButton("&Start");
    PB_Stop = new QPushButton("S&top");
    PB_Show = new QPushButton("Show &DB");

    tb_view = new QTableView;

    TE_Show = new QTextEdit();

    /* Layout Creation */
    QGridLayout *LayOut = new QGridLayout();
    QHBoxLayout *LayOut_H = new QHBoxLayout();

    /* Adding the Push Button and Text Editor in LayOut */
    LayOut_H->addWidget(PB_Start);
    LayOut_H->addWidget(PB_Stop);
    LayOut_H->addWidget(PB_Show);
    ;

    LayOut->addLayout(LayOut_H,0,0);
    LayOut->addWidget(TE_Show);
    LayOut->addWidget(tb_view);

    PB_Start->setPalette(DEFAULT_CONTROLS_STYLESHEET_DEFAULT);
    PB_Stop->setPalette(DEFAULT_CONTROLS_STYLESHEET_DEFAULT);
    PB_Show->setPalette(DEFAULT_CONTROLS_STYLESHEET_DEFAULT);

    widget->setLayout(LayOut);

    widget->setGeometry(200,200,400,400);

    widget->show();

    connect(PB_Start, SIGNAL(clicked()), this, SLOT(Server_Start()));
    connect(PB_Stop, SIGNAL(clicked()), this, SLOT(Server_Stop()));
    connect(PB_Show, SIGNAL(clicked()), this, SLOT(ShowDataBase()));

    tcpServer = new QTcpServer(this);

    this->setWindowTitle("MiddleServer");

    Model = new QSqlTableModel(this);

    /** SQL **/
    db = QSqlDatabase::addDatabase("QSQLITE");

    db.setDatabaseName("./message_log.db");


    if(db.isValid())
    {
        if (!db.open())
        {
            qDebug()<<db.lastError();
        }
        else
        {
            printf("db open Successfully\n");

            QSqlQuery sqlquery(db);

            /** Delete the Table **/
            //            sqlquery.exec("drop table MidServerLog");

            /** Creating New Table */
            sqlquery.exec("create table MidServerLog(Server1Log varchar(100) null,Server2Log varchar(100) null,CurTimeStampe TIMESTAMP not null default current_timestamp)");

            /** Query Tsting **/
//            sqlquery.exec("insert into MidServerLog(Server1Log)values('Weather')");
/*
            qDebug()<<"Size:"<<sqlquery.record().count();

            sqlquery.next();

            sqlquery.next();

            while(((sqlquery.record().count())>icnt))
            {
                qDebug()<< sqlquery.value(icnt).toString()<<endl;
                ++icnt;
            }
 */
        }
    }
    else
    {
        qDebug()<<"Invalid DB";
    }

}

MainWindow::~MainWindow()
{
    db.close();
    delete ui;
}

void MainWindow::Server_Start()
{

    PB_Start->setPalette(DEFAULT_CONTROLS_STYLESHEET_SELECT);
    PB_Stop->setPalette(DEFAULT_CONTROLS_STYLESHEET_DEFAULT);


    if (!tcpServer->listen(QHostAddress::Any, 1800))
    {
        TE_Show->append(tr("<font color=\"red\"><b>Error!</b> The port is taken by some other service.</font>"));
        return;
    }

    connect(tcpServer, &QTcpServer::newConnection, this, &MainWindow::newConnection);
    TE_Show->append(tr("<font color=\"green\"><b>Server started</b></font>"));
    TE_Show->append(tr("Connection Established"));
}

void MainWindow::Server_Stop()
{

    PB_Start->setPalette(DEFAULT_CONTROLS_STYLESHEET_DEFAULT);
    PB_Stop->setPalette(DEFAULT_CONTROLS_STYLESHEET_SELECT);

    if(tcpServer->isListening())
    {
        disconnect(tcpServer, &QTcpServer::newConnection, this, &MainWindow::newConnection);
        tcpServer->close();
        //        clientSocket->close();
        TE_Show->append(tr("<b>Server stopped</b>, post is closed"));
    }
    else
    {
        TE_Show->append(tr("<b>Error!</b> Server was not running"));
        PB_Start->setPalette(DEFAULT_CONTROLS_STYLESHEET_DEFAULT);
    }
}

void MainWindow::newConnection()
{
    QTcpSocket *clientSocket = tcpServer->nextPendingConnection();

    connect(clientSocket, &QTcpSocket::disconnected, clientSocket, &QTcpSocket::deleteLater);
    connect(clientSocket, &QTcpSocket::readyRead, this, &MainWindow::readClient);
    connect(clientSocket, &QTcpSocket::disconnected, this, &MainWindow::gotDisconnection);

    clients << clientSocket;

    sendToClient(clientSocket, "connection established");

    TE_Show->append(tr("Connection Established"));
}

void MainWindow::readClient()
{
    qDebug()<<"Inside Client";

    QTcpSocket *clientSocket = (QTcpSocket*)sender();
    char arr[256];
    QString str;

    if(clientSocket->bytesAvailable())
    {
        memset(arr,0,sizeof(arr));
        clientSocket->read(arr,clientSocket->bytesAvailable());
        str.sprintf("%s",arr);
    }

    if(clients.at(0) == clientSocket)
    {
        QSqlQuery sqlquery;
        QString qstr;
        qstr.sprintf("insert into MidServerLog(Server1Log)values('%s')",arr);
        qDebug()<<qstr;
        sqlquery.exec(qstr);
        str = "Message From Client 1: "+ str;
        sendToClient(clients.at(1), str);
    }
    else
    {
        QSqlQuery sqlquery;
        QString qstr;
        qstr.sprintf("insert into MidServerLog(Server2Log)values('%s')",arr);
        sqlquery.exec(qstr);
        qDebug()<<qstr;
        str = "Message From Client 2: "+ str;
        sendToClient(clients.at(0), str);
    }

    TE_Show->append(str);
    qDebug() << str;
}

void MainWindow::gotDisconnection()
{
    clients.at(clients.indexOf((QTcpSocket*)sender()))->close();
    clients.removeAt(clients.indexOf((QTcpSocket*)sender()));

    TE_Show->append(tr("Disconnected from Client"));
}

qint64 MainWindow::sendToClient(QTcpSocket* socket, const QString& str)
{
    return socket->write(str.toLatin1().data(),str.size());
}


void MainWindow::ShowDataBase()
{

    Model = new QSqlTableModel(this,db);

    Model->setTable("MidServerLog");
    Model->select();

    tb_view->setModel(Model);

}
