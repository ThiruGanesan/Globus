#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpServer>
#include <QTcpSocket>
#include <QDataStream>
#include <QList>
#include <QPushButton>
#include <QLabel>
#include <QTextEdit>
#include <QGridLayout>
#include <QTableView>
#include <QSqlRelationalTableModel>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>

#include "QtSql"

#define DEFAULT_CONTROLS_STYLESHEET_SELECT          QPalette(QColor(0, 255, 0))
//#define DEFAULT_CONTROLS_STYLESHEET_DEFAULT         QPalette(QColor(255,32,73))
#define DEFAULT_CONTROLS_STYLESHEET_DEFAULT         QPalette(QColor(143, 144, 135))

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    int m_ScreenWidth;
    int m_ScreenHeight;

    QPushButton *PB_Start;
    QPushButton *PB_Stop;
    QPushButton *PB_Show;

    QTextEdit *TE_Show;

    QTableView *tb_view;

    QTcpServer *tcpServer;
    QTcpSocket *clientSocket;
    QList<QTcpSocket*> clients;

    virtual void newConnection();
    void readClient();
    void gotDisconnection();
    qint64 sendToClient(QTcpSocket *socket, const QString &str);

    QSqlDatabase db;
    QString qStr,qTempStr,qTempStr1;

    QSqlTableModel *Model;

signals:
    void gotNewMesssage(QString msg);
    void ClientDisconnected();


public slots:
    void Server_Start();
    void Server_Stop();
    void ShowDataBase();



private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
