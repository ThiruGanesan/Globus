#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include <QTcpServer>
#include <QTcpSocket>
#include <QDataStream>
#include <QList>
#include <QPushButton>
#include <QLabel>
#include <QTextEdit>
#include <QGridLayout>
#include <QLineEdit>
#include <QString>
#include <QTcpSocket>
#include <QDataStream>
#include <QTimer>

#define DEFAULT_CONTROLS_STYLESHEET_SELECT          QPalette(QColor(0, 255, 0))
//#define DEFAULT_CONTROLS_STYLESHEET_DEFAULT         QPalette(QColor(255,32,73))
#define DEFAULT_CONTROLS_STYLESHEET_DEFAULT         QPalette(QColor(143, 144, 135))


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    int m_ScreenWidth;
    int m_ScreenHeight;

    QPushButton *PB_Connect;
    QPushButton *PB_DisConnect;

    QPushButton *PB_Send;
    QLineEdit *LE_Text;

    QTextEdit *TE_Show;

    QTcpServer *tcpServer;
    QTcpSocket *clientSocket;
    QList<QTcpSocket*> clients;

    QTcpSocket *tcpSocket;
    bool getStatus();

    void receivedData(QString msg);

public slots:
    void closeConnection();
    void connectTohost(const QString hostAddress,int portNumber);

    void Clinet_Connect();
    void Clinet_DisConnect();
    void Send_Data();
    void readyRead();
    void connected();
    void connectionTimeout();

    void ErrorNo(QAbstractSocket::SocketError err);
    void StatusDetails(bool bStatus);

private:
    bool status;
    QTimer *timeoutTimer;


private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
