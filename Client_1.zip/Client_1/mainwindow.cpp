#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QWidget *widget = new QWidget();

    PB_Connect = new QPushButton("Connect");
    PB_DisConnect = new QPushButton("DisConnect");
    PB_Send = new QPushButton("Send");
    LE_Text = new QLineEdit();
    TE_Show = new QTextEdit();

    QGridLayout *LayOut = new QGridLayout();
    QHBoxLayout *LayOut_H1 = new QHBoxLayout();
    QHBoxLayout *LayOut_H2 = new QHBoxLayout();

    LayOut_H1->addWidget(PB_Connect);
    LayOut_H1->addWidget(PB_DisConnect);

    LayOut_H2->addWidget(PB_Send);
    LayOut_H2->addWidget(LE_Text);

    LayOut->addLayout(LayOut_H1,0,0);
    LayOut->addLayout(LayOut_H2,30,0);
    LayOut->addWidget(TE_Show);

    PB_Connect->setPalette(DEFAULT_CONTROLS_STYLESHEET_DEFAULT);
    PB_DisConnect->setPalette(DEFAULT_CONTROLS_STYLESHEET_DEFAULT);

    widget->setLayout(LayOut);
    widget->setGeometry(0,0,400,400);

    widget->show();

    connect(PB_Connect, SIGNAL(clicked()), this, SLOT(Clinet_Connect()));
    connect(PB_DisConnect, SIGNAL(clicked()), this, SLOT(Clinet_DisConnect()));
    connect(PB_Send, SIGNAL(clicked()), this, SLOT(Send_Data()));

    status = false;

    tcpSocket = new QTcpSocket(this);
    connect(tcpSocket, &QTcpSocket::disconnected, this, &MainWindow::closeConnection);

    timeoutTimer = new QTimer();
    timeoutTimer->setSingleShot(true);
    connect(timeoutTimer, &QTimer::timeout, this, &MainWindow::connectionTimeout);

    connect(tcpSocket, SIGNAL(error(QAbstractSocket::SocketError)),this, SLOT(ErrorNo(QAbstractSocket::SocketError)));

    this->setWindowTitle("Client_1");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::Clinet_Connect()
{
    Clinet_DisConnect();
    PB_Connect->setPalette(DEFAULT_CONTROLS_STYLESHEET_SELECT);
    PB_DisConnect->setPalette(DEFAULT_CONTROLS_STYLESHEET_DEFAULT);

    connectTohost("localhost",1800);
}

void MainWindow::Clinet_DisConnect()
{

    PB_Connect->setPalette(DEFAULT_CONTROLS_STYLESHEET_DEFAULT);
    PB_DisConnect->setPalette(DEFAULT_CONTROLS_STYLESHEET_SELECT);

    closeConnection();
}
void MainWindow::Send_Data()
{
    QString qsData = LE_Text->text();
    tcpSocket->write(qsData.toLatin1().data());
    LE_Text->clear();
}


void MainWindow::connectTohost(const QString hostAddress,int portNumber)
{
    timeoutTimer->start(3000);

    tcpSocket->connectToHost(hostAddress, portNumber);
    connect(tcpSocket, &QTcpSocket::connected, this, &MainWindow::connected);
    connect(tcpSocket, &QTcpSocket::readyRead, this, &MainWindow::readyRead);
}

void MainWindow::connectionTimeout()
{
    if(tcpSocket->state() == QAbstractSocket::ConnectingState)
    {
        tcpSocket->abort();
        emit tcpSocket->error(QAbstractSocket::SocketTimeoutError);
    }
}

void MainWindow::connected()
{
    status = true;
    StatusDetails(status);
}

void MainWindow::readyRead()
{
    char carrData[256];
    QString qsData;

    if(tcpSocket->bytesAvailable())
    {
        memset(carrData,0,sizeof(carrData));
        tcpSocket->read(carrData,tcpSocket->bytesAvailable());
        qsData.sprintf("%s",carrData);
    }

    receivedData(qsData);
}

void MainWindow::closeConnection()
{
    timeoutTimer->stop();
    disconnect(tcpSocket, &QTcpSocket::connected, 0, 0);
    disconnect(tcpSocket, &QTcpSocket::readyRead, 0, 0);

    bool Control = false;
    switch (tcpSocket->state())
    {
    case 0:
        tcpSocket->disconnectFromHost();
        Control = true;
        break;
    case 2:
        tcpSocket->abort();
        Control = true;
        break;
    default:
        tcpSocket->abort();
    }

    if (Control)
    {
        status = false;
        StatusDetails(status);
    }
}

void MainWindow::receivedData(QString msg)
{
    TE_Show->append(msg);
}

void MainWindow::ErrorNo(QAbstractSocket::SocketError errDetails)
{
    QString strError = "unknown";

    PB_Connect->setPalette(DEFAULT_CONTROLS_STYLESHEET_DEFAULT);

    switch (errDetails)
    {
    case 0:
        strError = "Error No : "+QString::number(errDetails)+", Connection was refused";
        break;
    case 5:
        strError = "Error No : "+QString::number(errDetails)+", Connection timed out";
        break;
    default:
        strError = "Error No : "+QString::number(errDetails)+", Unknown error";
    }

    TE_Show->append(strError);
}
void MainWindow::StatusDetails(bool bStatus)
{
    if(bStatus)
    {

        TE_Show->append(tr("<font color=\"green\">CONNECTED</font>"));
    }
    else
    {
        TE_Show->append(tr("<font color=\"red\">DISCONNECTED</font>"));
        PB_Connect->setPalette(DEFAULT_CONTROLS_STYLESHEET_DEFAULT);
    }
}

